<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('asset_monitors', function (Blueprint $table) {
            $table->string('fixed_asset_code')
                ->nullable()
                ->after('refresh_rate');
        });
    }

    public function down(): void
    {
        Schema::table('asset_monitors', function (Blueprint $table) {
            $table->dropColumn('fixed_asset_code');
        });
    }
};